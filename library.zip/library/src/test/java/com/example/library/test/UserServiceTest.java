package com.example.library.test;

import com.example.library.bean.User;
import com.example.library.service.UserService;
import com.example.library.service.impl.UserServiceImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserServiceTest {

    UserService userService = new UserServiceImpl();

    @Test
    public void registUser() {
        userService.registUser(new User(195030101,"195030101","195030101@qq.com"));
    }

    @Test
    public void login() {
        System.out.println(userService.login(new User(195030103,"1234568",null)));
        System.out.println(userService.login(new User(195030103,"12345678",null)));
    }

    @Test
    public void existUsername() {
        if(userService.existUsername(195030103))
        {
            System.out.println("用户名已存在");
        }
        else
        {
            System.out.println("用户名可用");
        }
    }
}