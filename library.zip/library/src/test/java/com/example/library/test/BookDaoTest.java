package com.example.library.test;

import com.example.library.bean.Book;
import com.example.library.bean.LendList;
import com.example.library.bean.Page;
import com.example.library.dao.BookDao;
import com.example.library.dao.impl.BookDaoImpl;
import com.example.library.service.BookService;
import com.example.library.service.impl.BookServiceImpl;
import org.junit.Test;

import java.sql.Date;
import java.util.List;

import static org.junit.Assert.*;

public class BookDaoTest {

    private BookDao bookDao = new BookDaoImpl();
    private BookService bookService = new BookServiceImpl();
    @Test
    public void addBook() {
        bookDao.addBook(new Book(6,"大话数据结构","程杰","中文",45,57.5,1,
                "images/book/data_structure.jpg"));
    }

    @Test
    public void deleteBookById() {
        bookDao.deleteBookById(4);
    }

    @Test
    public void updateBook() {
        bookDao.updateBook(new Book(2,"大话设计模式","程杰","中文",30,45.0,1,
                "images/book/data_structure.jpg"));
    }

    @Test
    public void queryBookById() {
        System.out.println(bookDao.queryBookById(1));
    }

    @Test
    public void queryBooks() {
        System.out.println(bookDao.queryBooks().toString());
    }

    @Test
    public void queryForPageTotalCount() {
        System.out.println(bookDao.queryForPageTotalCount());
    }

    @Test
    public void queryForPageItems() {
        for(Book book : bookDao.queryForPageItems(0, Page.PAGE_SIZE))
        {
            System.out.println(book);
        }
    }
    @Test
    public void page()
    {
        System.out.println(bookService.page(1,Page.PAGE_SIZE));
    }
    @Test
    public void pageForUser()
    {
        System.out.println(bookService.page(1,Page.PAGE_SIZE));
    }

    @Test
    public void addLendList() {
        java.util.Date date = new java.util.Date();
        Date lend_date = new Date(date.getTime());  //得到借书时间
        Date back_date = new Date(date.getTime()+7776000000L);
        System.out.println(back_date);  //还书时间
        bookDao.addLendList(new LendList(1,2,195030103,lend_date,back_date));
    }

    @Test
    public void queryForLendListTotalCount() {
        System.out.println(bookDao.queryForLendListTotalCount(195030103));
    }

    @Test
    public void queryForLendListItems() {
        System.out.println(bookDao.queryForLendListItems(195030103,0,4));
    }
    @Test
    public void deleteLendListById() {
    bookDao.deleteLendListById(16);
    }

}