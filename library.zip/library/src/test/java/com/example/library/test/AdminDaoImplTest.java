package com.example.library.test;

import com.example.library.dao.AdminDao;
import com.example.library.dao.UserDao;
import com.example.library.dao.impl.AdminDaoImpl;
import com.example.library.dao.impl.UserDaoImpl;
import org.junit.Test;

import static org.junit.Assert.*;

public class AdminDaoImplTest {
    AdminDao adminDao = new AdminDaoImpl();
    @Test
    public void queryAdminByIdAndPassword() {
        if(adminDao.queryAdminByIdAndPassword(195030103,"123456789")==null)
        {
            System.out.println("用户名或者密码错误，登录失败!");
        }
        else
        {
            System.out.println("登录成功！");
        }
    }
}