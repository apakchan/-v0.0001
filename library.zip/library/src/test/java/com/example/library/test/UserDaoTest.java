package com.example.library.test;

import com.example.library.bean.User;
import com.example.library.dao.UserDao;
import com.example.library.dao.impl.UserDaoImpl;
import org.junit.Test;

import java.sql.Date;

import static org.junit.Assert.*;

public class UserDaoTest {

    UserDao userDao = new UserDaoImpl();

    @Test
    public void queryUserByUsername() {
        if(userDao.queryUserByUsername(1950301034) == null)
        {
            System.out.println("用户名可用");
        }
        else {
            System.out.println("用户名已存在");
        }

    }

    @Test
    public void saveUser() {
        System.out.println(userDao.saveUser(new User(195080103,"123456789","cby@163.com")));
    }

    @Test
    public void queryUserByUsernameAndPassword() {
        if(userDao.queryUserByUsernameAndPassword(195030103,"12345678")==null)
        {
            System.out.println("用户名或者密码错误，登录失败!");
        }
        else
        {
            System.out.println("登录成功！");
        }
    }
    @Test
    public void time()
    {
        java.util.Date date = new java.util.Date();
        System.out.println(date.getTime());
        Date lend_date = new Date(date.getTime());  //得到借书时间
        System.out.println(lend_date);
        Date back_date = new Date(date.getTime()+7776000000L);
        System.out.println(back_date);
    }

    @Test
    public void changePwd()
    {
        userDao.changePwd(195030101,"123456789");
    }
}