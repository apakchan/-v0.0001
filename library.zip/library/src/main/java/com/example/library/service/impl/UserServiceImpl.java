package com.example.library.service.impl;

import com.example.library.bean.User;
import com.example.library.dao.UserDao;
import com.example.library.dao.impl.UserDaoImpl;
import com.example.library.service.UserService;

/**
 * @author 陈柏宇
 */

public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDaoImpl();

    @Override
    public void registUser(User user) {
        userDao.saveUser(user);
    }

    @Override
    public User login(User user) {

        return userDao.queryUserByUsernameAndPassword(user.getId(),user.getPassword());
    }

    @Override
    public boolean existUsername(Integer id) {
        if(userDao.queryUserByUsername(id) == null)
        {
            //没查到这个id的用户,可用
            return false;
        }
        return true;
    }

    @Override
    public void changePwd(Integer username,String pwd)
    {
        userDao.changePwd(username,pwd);
    }
}
