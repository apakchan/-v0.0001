package com.example.library.dao.impl;

import com.example.library.bean.Book;
import com.example.library.bean.LendList;
import com.example.library.dao.BookDao;

import java.util.List;

/**
 * @author 陈柏宇
 *
 */

public class BookDaoImpl extends BaseDao implements BookDao {
    /**
     * 往数据库中添加一本书
     * @param book 要添加的书
     * @return -1表示添加失败
     */
    @Override
    public int addBook(Book book) {
        String sql = "insert into t_book(name,author,language,number,price,class_id,img_path) values(?,?,?,?,?,?,?)";

        return update(sql,book.getName(),book.getAuthor(),book.getLanguage(),book.getNumber(),book.getPrice(),book.getClass_id(),book.getImg_path());
    }

    /**
     * 按照id删除一本书
     * @param id id号
     * @return -1表示删除失败
     */
    @Override
    public int deleteBookById(Integer id) {
        String sql = "delete from t_book where id =?";
        return update(sql,id);
    }

    /**
     * 更新一本书的信息
     * @param book 更新的书的信息
     * @return -1表示更新失败
     */
    @Override
    public int updateBook(Book book) {
        String sql = "update t_book set name=?,author =?,language=?,number=?,price=?,class_id=?,img_path=? where id = ?";
        return update(sql,book.getName(),book.getAuthor(),book.getLanguage(),book.getNumber(),book.getPrice(),book.getClass_id(),book.getImg_path(),book.getId());
    }

    /**
     * 按照id查询具体的图书
     * @param id id
     * @return 返回一本图书
     */
    @Override
    public Book queryBookById(Integer id) {
        String sql = "select id,name,author,language,number,price,class_id,img_path from t_book where id = ?";
        return queryForOne(Book.class,sql,id);
    }

    /**
     * 返回全部图书信息，用List存储
     * @return 返回一个List集合
     */
    @Override
    public List<Book> queryBooks() {
        String sql = "select id,name,author,language,number,price,class_id,img_path from t_book";
        return queryForList(Book.class,sql);
    }

    @Override
    public Integer queryForPageTotalCount() {
        String sql = "select count(*) from t_book";
        Number count = (Number) queryForSingleValue(sql);
        return count.intValue();
    }

    @Override
    public List<Book> queryForPageItems(Integer begin, Integer pageSize) {
        String sql = "select id,name,author,language,number,price,class_id,img_path from t_book limit ?,?";
        return queryForList(Book.class,sql,begin,pageSize);
    }

    @Override
    public int addLendList(LendList lendList) {
        String sql = "insert into t_lend_list(book_id,reader_id,lend_date,back_date) values(?,?,?,?)";
        return update(sql,lendList.getBook_id(),lendList.getReader_id(),lendList.getLend_date(),lendList.getBack_date());
    }

    @Override
    public Integer queryForLendListTotalCount(Integer username) {
        String sql = "select count(*) from t_lend_list where reader_id = ?";
        Number count = (Number) queryForSingleValue(sql,username);
        return count.intValue();
    }

    @Override
    public List<LendList> queryForLendListItems(Integer username,Integer begin, Integer pageSize) {
        String sql = "select id,book_id,reader_id,lend_date,back_date from (select id,book_id,reader_id,lend_date,back_date from t_lend_list where reader_id = ? ) a limit ?,?";
        return queryForList(LendList.class,sql,username,begin,pageSize);
    }

    @Override
    public void deleteLendListById(Integer id) {
        String sql = "delete from t_lend_list where id = ?";
        update(sql,id);
    }
}
