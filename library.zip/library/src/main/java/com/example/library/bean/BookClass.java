package com.example.library.bean;

/**
 * @author 陈柏宇
 * 图书类的类
 */

public class BookClass {
    private Integer class_id;
    private String name;

    public BookClass() {
    }

    public BookClass(Integer class_id, String name) {
        this.class_id = class_id;
        this.name = name;
    }

    public Integer getClass_id() {
        return class_id;
    }

    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "BookClass{" +
                "class_id=" + class_id +
                ", name='" + name + '\'' +
                '}';
    }
}
