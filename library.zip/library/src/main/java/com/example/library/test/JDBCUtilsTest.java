package com.example.library.test;

import com.example.library.utils.JdbcUtils;
import org.junit.Test;

import java.sql.Connection;

public class JDBCUtilsTest {

    @Test
    public void test1()
    {
        for (int i = 0; i < 100 ; i ++)
        {
            Connection conn = JdbcUtils.getConnection();
            System.out.println(conn);
            JdbcUtils.close(conn);
        }
    }

}
