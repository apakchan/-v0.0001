package com.example.library.service;

import com.example.library.bean.Book;
import com.example.library.bean.LendList;
import com.example.library.bean.Page;

import java.util.List;

/**
 * @author 陈柏宇
 */

public interface BookService {
    public void addBook(Book book);

    public void deleteBook(Integer id);

    public void updateBook(Book book);

    public Book queryBookById(Integer id);

    public List<Book> queryBooks();

    public Page<Book> page(Integer pageNo, Integer pageSize);

    public void addLendList(LendList lendList);

    public Page<LendList> pageForLendList(Integer pageNo, Integer pageSize,Integer username);

    public void deleteLendList(Integer id);
}
