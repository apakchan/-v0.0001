package com.example.library.dao.impl;

import com.example.library.bean.User;
import com.example.library.dao.UserDao;

/**
 * @author 陈柏宇
 * 按照顺序分别是
 * 根据学号查询具体的学生
 * 保存一个学生信息
 * 根据学号密码查询学生
 */

public class UserDaoImpl extends BaseDao implements UserDao {
    @Override
    public User queryUserByUsername(Integer id) {
        String sql = "select id,password,email from t_user where id = ?";

        return queryForOne(User.class,sql,id);
    }

    @Override
    public int saveUser(User user) {
        String sql = "insert into t_user(id,password,email) values(?,?,?)";
        return update(sql,user.getId(),user.getPassword(),user.getEmail());
    }

    @Override
    public User queryUserByUsernameAndPassword(Integer id, String password) {
        String sql = "select id,password,email from t_user where id = ? and password = ?";

        return queryForOne(User.class,sql,id,password);
    }

    @Override
    public void changePwd(Integer username, String pwd) {
        String sql = "update t_user set password = ? where id = ?";
        update(sql,pwd,username);
    }
}
