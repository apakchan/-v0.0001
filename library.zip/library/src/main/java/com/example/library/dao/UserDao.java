package com.example.library.dao;

import com.example.library.bean.User;

public interface UserDao {



    /**
     * 根据学号查询学生信息
     * @param id  学号
     * @return  用户对象  如果返回null说明没有这个用户，否则说明有
     */
    public User queryUserByUsername(Integer id);

    /**
     * 保存用户信息
     * @param user  要保存到数据库的用户
     * @return
     */
    public int saveUser(User user);

    /**
     * 根据学号和密码查询用户
     * @param id           学号
     * @param password     密码
     * @return             返回一个具体的用户，如果返回null说明没有这个用户 || (学号 || 密码) 错误
     */
    public User queryUserByUsernameAndPassword(Integer id,String password);

    public void changePwd(Integer username,String pwd);
}
