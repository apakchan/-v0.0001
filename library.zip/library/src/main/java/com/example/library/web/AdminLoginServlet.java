package com.example.library.web;

import com.example.library.bean.Admin;
import com.example.library.service.AdminService;
import com.example.library.service.impl.AdminServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AdminLoginServlet extends BaseServlet {

    private AdminService adminService = new AdminServiceImpl();

    /**
     * 管理员登录
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException{
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        if(adminService.login(new Admin(Integer.parseInt(username),password)) == null)
        {
            ///如果返回空说明数据库中没有这个管理员
            req.getRequestDispatcher("/html/admin_login_false.jsp").forward(req,resp);
        }
        else{
            //说明数据库中有这个管理员
            req.getRequestDispatcher("/html/manager/manager.jsp").forward(req,resp);
        }
    }


}
