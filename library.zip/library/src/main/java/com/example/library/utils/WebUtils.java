package com.example.library.utils;

import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * @author 陈柏宇
 *
 */

public class WebUtils {
    /**
     * 通过传入的请求req得到表单中的值，再把值传入到bean对象中，
     * 但是要注意，Bean中的属性值的名字一定要和表单的名字相同，类型可以不同(反射)
     *
     * 把map中的值注入到对应的JavaBean属性中，这样写代码的耦合度更低
     * @param value
     * @param bean
     * DAO层
     * Service层
     * Web层
     * 降低了代码的耦合度
     * 使用泛型，不用类型转换
     */
    public static <T> T copyParamToBean(Map value, T bean)
    {
        try {
            //使用: Bean bean = WebUtils.copyParamToBean(req.getParameterMap(),bean)
            BeanUtils.populate(bean,value);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        return bean;
    }

    /**
     * 把字符串转换为数字，如果转换成功则返回数字，否则返回默认值
     * @param strInt  转换的字符串
     * @param defaultValue  默认值
     * @return  返回数字
     */
    public static int parseInt(String strInt,int defaultValue)
    {
        try {
            return Integer.parseInt(strInt);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return defaultValue;
    }
}
