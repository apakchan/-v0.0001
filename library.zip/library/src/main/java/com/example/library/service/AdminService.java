package com.example.library.service;

import com.example.library.bean.Admin;


public interface AdminService {

    /**
     *
     * @param admin  一个具体的管理员信息
     * @return  如果返回空说明没有这个管理员
     */
    public Admin login(Admin admin);
}
