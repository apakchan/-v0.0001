package com.example.library.bean;

/**
 * @author 陈柏宇
 * 图书类
 */

public class Book {
    private Integer id;
    private String name;
    private String author;
    private String language;
    private Integer number;
    private Double price;
    private Integer class_id;
    private String img_path;

    public String getImg_path() {
        return img_path;
    }

    public void setImg_path(String img_path) {
        this.img_path = img_path;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getClass_id() {
        return class_id;
    }

    public void setClass_id(Integer class_id) {
        this.class_id = class_id;
    }

    public Book() {
    }

    public Book(Integer id, String name, String author, String language, Integer number, Double price, Integer class_id, String img_path) {
        this.id = id;
        this.name = name;
        this.author = author;
        this.language = language;
        this.number = number;
        this.price = price;
        this.class_id = class_id;
        //给定的图书封面路径不能为空
        if(img_path != null && !img_path.equals("")) {
            this.img_path = img_path;
        }
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", language='" + language + '\'' +
                ", number=" + number +
                ", price=" + price +
                ", class_id=" + class_id +
                ", img_path='" + img_path + '\'' +
                '}';
    }
}
