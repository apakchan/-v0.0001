package com.example.library.service.impl;

import com.example.library.bean.Book;
import com.example.library.bean.LendList;
import com.example.library.bean.Page;
import com.example.library.dao.BookDao;
import com.example.library.dao.impl.BookDaoImpl;
import com.example.library.service.BookService;

import java.util.List;

/**
 * @author 陈柏宇
 */

public class BookServiceImpl implements BookService
{

    private BookDao bookDao = new BookDaoImpl();

    @Override
    public void addBook(Book book) {

        bookDao.addBook(book);
    }

    @Override
    public void deleteBook(Integer id) {
        bookDao.deleteBookById(id);
    }

    @Override
    public void updateBook(Book book) {
        bookDao.updateBook(book);
    }

    @Override
    public Book queryBookById(Integer id) {
        return bookDao.queryBookById(id);
    }

    @Override
    public List<Book> queryBooks() {
        return bookDao.queryBooks();
    }

    @Override
    public Page<Book> page(Integer pageNo, Integer pageSize) {
        Page<Book> page = new Page<Book>();
        //当前页码
        page.setPageNo(pageNo);
        //一页的记录数
        page.setPageSize(pageSize);
        //总计录数
        Integer pageTotalCount = bookDao.queryForPageTotalCount();
        page.setPageTotalCount(pageTotalCount);
        //总页数
        Integer pageTotal =(pageTotalCount % pageSize == 0)? pageTotalCount / pageSize : pageTotalCount / pageSize + 1;
        page.setPageTotal(pageTotal);
        //当前页数据的开始索引
        int begin = (pageNo - 1) * pageSize;
        //求当前页数据
        List<Book> items= bookDao.queryForPageItems(begin,pageSize);
        page.setItems(items);

        return page;
    }

    @Override
    public void addLendList(LendList lendList) {
        bookDao.addLendList(lendList);
    }

    @Override
    public Page<LendList> pageForLendList(Integer pageNo, Integer pageSize,Integer username) {
        Page<LendList> page = new Page<LendList>();
        //当前页码
        page.setPageNo(pageNo);
        //一页的记录数
        page.setPageSize(pageSize);
        //总计录数
        Integer pageTotalCount = bookDao.queryForLendListTotalCount(username);
        page.setPageTotalCount(pageTotalCount);
        //总页数
        Integer pageTotal =(pageTotalCount % pageSize == 0)? pageTotalCount / pageSize : pageTotalCount / pageSize + 1;
        page.setPageTotal(pageTotal);
        //当前页数据的开始索引
        int begin = (pageNo - 1) * pageSize;
        //求当前页数据
        List<LendList> items= bookDao.queryForLendListItems(username,begin,pageSize);
        page.setItems(items);

        return page;
    }

    @Override
    public void deleteLendList(Integer id) {
        bookDao.deleteLendListById(id);
    }
}
