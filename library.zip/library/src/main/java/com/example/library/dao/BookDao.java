package com.example.library.dao;

import com.example.library.bean.Book;
import com.example.library.bean.LendList;

import java.util.List;

/**
 * @author 陈柏宇
 *
 */

public interface BookDao {
   public int addBook(Book book);

   public int deleteBookById(Integer id);

   public int updateBook(Book book);

   public Book queryBookById(Integer id);

   public List<Book> queryBooks();

   public Integer queryForPageTotalCount();

   public List<Book> queryForPageItems(Integer begin,Integer pageSize);

   public int addLendList(LendList lendList);

   public Integer queryForLendListTotalCount(Integer username);

   public List<LendList> queryForLendListItems(Integer username,Integer begin,Integer pageSize);

   public void deleteLendListById(Integer id);
}
