package com.example.library.web;

import com.example.library.bean.Book;
import com.example.library.bean.LendList;
import com.example.library.bean.Page;
import com.example.library.service.BookService;
import com.example.library.service.impl.BookServiceImpl;
import com.example.library.utils.WebUtils;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

/**
 * @author 陈柏宇
 */

public class BookServlet extends BaseServlet {
    private BookService bookService = new BookServiceImpl();
    /**
     * 添加图书
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void add(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        
        //1.获取请求的参数 封装成为Book对象
        String name = req.getParameter("name");
        String author = req.getParameter("author");
        String language = req.getParameter("language");
        Integer number = Integer.parseInt(req.getParameter("number"));
        Double price = Double.parseDouble(req.getParameter("price"));
        Integer class_id = Integer.parseInt(req.getParameter("class_id"));
        String img_path = req.getParameter("img_path");
        Book book = new Book(null,name,author,language,number,price,class_id,img_path);

        //2.调用BookService.addBook()保存图书
        bookService.addBook(book);
        //3.跳转到图书列表页面  /manager/bookServlet?action=list
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page");

    }

    /**
     * 删除图书
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void delete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获取参数id
        int id = WebUtils.parseInt(req.getParameter("id"),-1);
        //2.调用bookService.deleteBookById()
        bookService.deleteBook(id);
        //3.重定向回图书列表管理页面
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page");
    }

    /**
     * 更新图书信息
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void update(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获取请求的参数封装成为book对象
        Integer id = WebUtils.parseInt(req.getParameter("id"),-1);
        String name = req.getParameter("name");
        String author = req.getParameter("author");
        String language = req.getParameter("language");
        Integer number = Integer.parseInt(req.getParameter("number"));
        Double price = Double.parseDouble(req.getParameter("price"));
        Integer class_id = Integer.parseInt(req.getParameter("class_id"));
        String img_path = req.getParameter("img_path");
        Book book = new Book(id,name,author,language,number,price,class_id,img_path);

        //2.调用bookService.updateBook(book)修改图书
        bookService.updateBook(book);
        //3.重定向图书列表管理页面
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=page");
    }
    /**
     * 借书
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void lend(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获取图书编号,读者编号，并且记录这条数据
        Integer book_id = WebUtils.parseInt(req.getParameter("id"),-1);
        Integer reader_id = WebUtils.parseInt(req.getParameter("username"),-1);
        java.util.Date date = new java.util.Date();
        Date lend_date = new Date(date.getTime());  //得到借书时间
        Date back_date = new Date(date.getTime()+7776000000L);
        LendList lendList = new LendList(null,book_id,reader_id,lend_date,back_date);
        bookService.addLendList(lendList);

        //2.更新图书信息：图书数量-1
        Book book = bookService.queryBookById(book_id);
        book.setNumber(book.getNumber() - 1);
        bookService.updateBook(book);
        //3.重定向回用户页面
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=pageForUser");
    }
    /**
     * 得到要修改的图书的信息
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void getBook(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获取请求的参数图书编号
        int id = WebUtils.parseInt(req.getParameter("id"),-1);

        //2.调用bookService.queryBookById查询图书
        Book book = bookService.queryBookById(id);

        //3.保存图书到Request域中
        req.setAttribute("book",book);
        //4.请求转发到/html/manager/book_edit.jsp
        req.getRequestDispatcher("/html/manager/book_edit.jsp").forward(req,resp);
    }

    /**
     * 处理分页业务
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void page(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获取请求的参数
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"),1);
        int pageSize = WebUtils.parseInt(req.getParameter("pageSize"), Page.PAGE_SIZE);
        //2.调用BookService.page(pageNo,pageSize):Page对象
        Page<Book> page = bookService.page(pageNo,pageSize);
        //3.保存page对象到request域中
        req.setAttribute("page",page);
        //4.请求转发到html/manager/manager.jsp
        req.getRequestDispatcher("/html/manager/manager.jsp").forward(req,resp);
    }
    protected void pageForUser(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获取请求的参数
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"),1);
        int pageSize = WebUtils.parseInt(req.getParameter("pageSize"), Page.PAGE_SIZE);
        //2.调用BookService.page(pageNo,pageSize):Page对象
        Page<Book> page = bookService.page(pageNo,pageSize);
        //3.保存page对象到request域中
        req.setAttribute("page",page);
        //4.请求转发到html/manager/manager.jsp
        req.getRequestDispatcher("/html/user/login_success.jsp").forward(req,resp);
    }
    /**
     * 查询图书信息
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void list(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.查询全部图书
        List<Book> books = bookService.queryBooks();
        //2.保存到Request域中
        req.setAttribute("books",books);
        //3.发送给html/manager/manager.jsp
        req.getRequestDispatcher("/html/manager/manager.jsp").forward(req,resp);
    }
    protected void pageForLendList(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int pageNo = WebUtils.parseInt(req.getParameter("pageNo"),1);
        int pageSize = WebUtils.parseInt(req.getParameter("pageSize"), Page.PAGE_SIZE);
        Cookie cookie = null;
        for (Cookie reqCookie : req.getCookies()) {
            if(reqCookie.getName().equals("username"))
            {
                cookie = reqCookie;
                break;
            }
        }
        Integer username = null;
        try {
            username = Integer.parseInt(cookie.getValue());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

        Page<LendList> lendList = bookService.pageForLendList(pageNo,pageSize,username);
        System.out.println(lendList);
        req.setAttribute("lendList",lendList);
        req.getRequestDispatcher("/html/user/lend_list.jsp").forward(req,resp);
    }
    protected void back(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.得到借阅单号
        Integer id = WebUtils.parseInt(req.getParameter("id"),-1);
        //2.删除借阅单号
        bookService.deleteLendList(id);
        //3.对应的书数量+1
        Integer book_id = WebUtils.parseInt(req.getParameter("book_id"),-1);
        System.out.println(book_id);
        Book book = bookService.queryBookById(book_id);  //查询到对应的图书
        System.out.println(book);
        book.setNumber(book.getNumber() + 1);
        bookService.updateBook(book);
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=pageForLendList");
    }
    protected void drop(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.得到借阅单号
        Integer id = WebUtils.parseInt(req.getParameter("id"),-1);
        //2.删除借阅单号
        bookService.deleteLendList(id);
        resp.sendRedirect(req.getContextPath()+"/manager/bookServlet?action=pageForLendList");
    }
}
