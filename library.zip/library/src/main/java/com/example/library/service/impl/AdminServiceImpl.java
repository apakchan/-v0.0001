package com.example.library.service.impl;

import com.example.library.bean.Admin;
import com.example.library.dao.AdminDao;
import com.example.library.dao.impl.AdminDaoImpl;
import com.example.library.service.AdminService;

/**
 * @author 陈柏宇
 */

public class AdminServiceImpl  implements AdminService {
    private AdminDao adminDao = new AdminDaoImpl();

    @Override
    public Admin login(Admin admin) {
        return adminDao.queryAdminByIdAndPassword(admin.getId(),admin.getPassword());
    }
}
