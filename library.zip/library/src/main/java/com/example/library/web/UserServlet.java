package com.example.library.web;

import com.example.library.bean.User;
import com.example.library.service.UserService;
import com.example.library.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;

/**
 * @author 陈柏宇
 * 用户登录以及注册模块
 *
 */

public class UserServlet extends BaseServlet {
    private UserService userService = new UserServiceImpl();

    /**
     * 登录功能
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        //1.获取请求的参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        //2.检查
        if(userService.login(new User(Integer.parseInt(username),password,null)) == null)
        {
            //如果数据库中没有这位用户的信息
            System.out.println(username + "不存在或者密码错误");
            //跳转回登录失败页面
            req.getRequestDispatcher("/html/login_false.jsp").forward(req,resp);
        }
        else
        {
            Cookie cookie = new Cookie("username",username);
            //一周
            cookie.setMaxAge(60 * 60 * 24 * 7);
            resp.addCookie(cookie);
            req.getRequestDispatcher("/html/user/login_success.jsp").forward(req,resp);
        }
    }

    /**
     * 注册功能
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void regist(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        //1.获取请求的参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String email = req.getParameter("email");

        //2.检查
        if(userService.existUsername(Integer.parseInt(username)))
        {
            //如果用户名存在，不可用
            //把错误信息和回显的表单项信息保存到request域中
            req.setAttribute("msg","此学号已被别人注册过！");
            req.setAttribute("username",username);
            //跳转回注册页面
            req.getRequestDispatcher("/html/regist_false.jsp").forward(req,resp);
        }
        else
        {
            userService.registUser(new User(Integer.parseInt(username),password,email));
            req.getRequestDispatcher("/html/regist_success.jsp").forward(req,resp);
        }
    }
    protected void changePwd(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Cookie cookie = null;
        for (Cookie reqCookie : req.getCookies()) {
            if(reqCookie.getName().equals("username"))
            {
                cookie = reqCookie;
                break;
            }
        }
        Integer username = null;
        try {
            username = Integer.parseInt(cookie.getValue());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        String pwd = req.getParameter("pwd");
        if(userService.login(new User(username,pwd,null)) == null)
        {
            //密码错误
            req.getRequestDispatcher("/html/user/login_success.jsp").forward(req,resp);
            resp.setContentType("text/html;charset=utf-8");
            resp.getWriter().write("<script type='text/javascript'>alert('密码错误!')</script>");
        }
        else{
            userService.changePwd(username,pwd);
            req.getRequestDispatcher("/html/user/login_success.jsp").forward(req,resp);
        }
    }

    protected void changeEmail(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        Cookie cookie = null;
        for (Cookie reqCookie : req.getCookies()) {
            if(reqCookie.getName().equals("username"))
            {
                cookie = reqCookie;
                break;
            }
        }
        Integer username = null;
        try {
            username = Integer.parseInt(cookie.getValue());
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }
}
