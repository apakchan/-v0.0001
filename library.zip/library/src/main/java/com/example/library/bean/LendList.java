package com.example.library.bean;

import java.sql.Date;

/**
 * @author 陈柏宇
 * 借阅单号类
 */

public class LendList {
    private Integer id;
    private Integer book_id;
    private Integer reader_id;
    private Date lend_date;
    private Date back_date;

    public LendList(Integer id, Integer book_id, Integer reader_id, Date lend_date, Date back_date) {
        this.id = id;
        this.book_id = book_id;
        this.reader_id = reader_id;
        this.lend_date = lend_date;
        this.back_date = back_date;
    }

    public LendList() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getBook_id() {
        return book_id;
    }

    public void setBook_id(Integer book_id) {
        this.book_id = book_id;
    }

    public Integer getReader_id() {
        return reader_id;
    }

    public void setReader_id(Integer reader_id) {
        this.reader_id = reader_id;
    }

    public Date getLend_date() {
        return lend_date;
    }

    public void setLend_date(Date lend_date) {
        this.lend_date = lend_date;
    }

    public Date getBack_date() {
        return back_date;
    }

    public void setBack_date(Date back_date) {
        this.back_date = back_date;
    }

    @Override
    public String toString() {
        return "LendList{" +
                "id=" + id +
                ", book_id=" + book_id +
                ", reader_id=" + reader_id +
                ", lend_date=" + lend_date +
                ", back_date=" + back_date +
                '}';
    }
}
