package com.example.library.service;

import com.example.library.bean.User;

/**
 * @author 陈柏宇
 * 业务层
 */

public interface UserService {
    /**
     * 注册用户
     * @param user
     */
    public void registUser(User user);

    /**
     * 登录
     * @param user  一个用户
     * @return  返回null说明登录失败，否则登录成功
     */
    public User login(User user);

    /**
     * 检查学号是否可用
     * @param id
     * @return  返回true表示用户名表示 用户名已经存在 返回false表示用户名不存在(可用)
     */
    public boolean existUsername(Integer id);

    public void changePwd(Integer username,String pwd);
}
