package com.example.library.dao.impl;

import com.example.library.bean.Admin;
import com.example.library.bean.User;
import com.example.library.dao.AdminDao;

/**
 * @author 陈柏宇
 * 根据id和密码查询是否有这个管理员
 */

public class AdminDaoImpl extends BaseDao implements AdminDao {
    @Override
    public Admin queryAdminByIdAndPassword(Integer id, String password) {
        String sql = "select id,password from t_admin where id = ? and password = ?";
        return queryForOne(Admin.class,sql,id,password);
    }
}
