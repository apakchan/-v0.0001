package com.example.library.dao;

import com.example.library.bean.Admin;

public interface AdminDao {

    /**
     * 根据id和密码查询管理员
     * @param id           id
     * @param password     密码
     * @return             返回一个具体的管理员，如果返回null说明没有这个管理员 || (id || 密码) 错误
     */
    public Admin queryAdminByIdAndPassword(Integer id, String password);
}
