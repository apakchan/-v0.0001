$(function (){
    $("#operate").click(function (){
        $("#list").show();
        $("#query").hide();
    })
    $("#select").click(function (){
        $("#list").hide();
        $("#query").show();
    })

    $("a.delete_class").click(function (){
        //在事件的function函数中有this对象，是当前正在响应事件的dom对象
        return confirm("您确定要删除【"+ $(this).parent().parent().find("td:first").text() + "】吗？");
    })
})