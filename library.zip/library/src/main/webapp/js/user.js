$(function (){
    $("#browse").click(function (){
        $("#list").show();
        $("#lend_back").hide();
        $("#miss").hide();
        $("#change_pwd").hide();
        $("#change_email").hide();
    })
    $("#lendBack").click(function (){
        $("#list").hide();
        $("#lend_back").show();
        $("#miss").hide();
        $("#change_pwd").hide();
        $("#change_email").hide();
    })
    $("#missing").click(function (){
        $("#list").hide();
        $("#lend_back").hide();
        $("#miss").show();
        $("#change_pwd").hide();
        $("#change_email").hide();
    })
    $("#c_pwd").click(function (){
        $("#list").hide();
        $("#lend_back").hide();
        $("#miss").hide();
        $("#change_pwd").show();
        $("#change_email").hide();
    })
    $("#c_email").click(function (){
        $("#list").hide();
        $("#lend_back").hide();
        $("#miss").hide();
        $("#change_pwd").hide();
        $("#change_email").show();
    })
})