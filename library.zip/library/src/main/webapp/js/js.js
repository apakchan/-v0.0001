$(function (){


        $("#login").click(function (){
            var username = $("#username").val();
            var patt = /^\d{7,13}$/;  //验证学号
            if(!patt.test(username))
            {
                console.log("wrong!");
                $("#usmReminder").text("学号格式不符学校要求！");
                return false;
            }
            console.log("yes!");
            $("#usmReminder").text("");
        })


    //验证学号: 8 - 12 位 纯数字
    //验证密码: 6 - 20 位 数字,字母,下划线,
    $("#register1").click(function (){
        //给注册绑定单机事件
        var username = $("#username1").val();
        var pwd = $("#pwd1").val();
        var repwd = $("#repwd").val();
        var email = $("#email").val();
        var patt1 = /^\d{7,13}$/;  //验证学号
        var patt2 = /^\w{6,20}$/;  //验证密码
        var patt3 = /^[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([-_.][a-zA-Z0-9]+)*\.[a-z]{2,}$/;
        //验证邮箱

        if(!patt1.test(username))
        {
            $("#usmReminder1").text("学号不符！");
            return false;
        }
        $("#usmReminder1").text("");

        if(!patt3.test(email))
        {
            $("#emailReminder").text("邮箱格式不正确！");
            return false;
        }
        $("#emailReminder").text("");

        if(!patt2.test(pwd))
        {
            $("#pwdReminder1").text("密码不符要求!");
            return false;
        }
        $("#pwdReminder1").text("");

        if(repwd != pwd)
        {
            $("#repwdReminder").text("密码不一致！");
            return false;
        }
        $("#repwdReminder").text("");
    });
})
